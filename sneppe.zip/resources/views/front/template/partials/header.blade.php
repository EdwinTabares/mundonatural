<nav class="uk-navbar-container z-depth-4 black" uk-navbar id="navMax">

    <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="{{ route('front.index') }}" class="uk-animation-toggle">
            		<img src="{{ asset('img/logoHeader.png') }}" class="logoHeader uk-animation-shake uk-animation-reverse"/>
            	</a>
            </li>            
        </ul>
    </div>

    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="{{ route('front.index') }}" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		Inicio
            	</a>
            </li>
            <li class="uk-active">
            	<a href="{{ route('front.about') }}" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		&#191;Qui&#233;nes Somos?
            	</a>
            </li>
            <li class="uk-active">
	            <a href="#" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Productos
	            </a>
            </li>
            <li class="uk-active">
	            <a href="#" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Servicios
	            </a>
            </li>
            <li class="uk-active">
	            <a href="javascript:scrollNotice();" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Noticias
	            </a>
            </li>
            <li class="uk-active">
	            <a href="#modal" uk-toggle class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Contactenos
	            </a>
            </li>
        </ul>
    </div>
    
</nav>

<div class="uk-navbar-container black z-depth-4" uk-navbar id="navMin">
    <div class="uk-navbar-left">
	    <button class="uk-button uk-button-default" id="button1" type="button" 
	    	style="margin:20px; border:none; width: 70px; height: 50px" 
	    		onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);border:none;width: 70px; height: 50px;margin:20px;'" 
	          	onMouseOut="this.style.cssText='background-color: transparent;border:none;width: 70px; height: 50px;margin:20px;'">
	    	<i id="icon" class="fa fa-plus white-text" align="center" style="font-size:18px" aria-hidden="true" 
	    		onMouseOver="this.style.cssText='font-size: 20px;'" 
	            onMouseOut="this.style.cssText='font-size: 18px;'"></i>
	    </button>
        <div uk-dropdown="mode: click;" class="black z-depth-4-white">
            <ul class="uk-nav uk-dropdown-nav black">
                <li class="uk-active">
	               	<a href="{{ route('front.index') }}" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	               		Inicio
	               	</a>
                </li>
                <li class="uk-active">
	                <a href="{{ route('front.about') }}" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	&#191;Qui&#233;nes Somos?
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Productos
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Servicios
	                </a>
                </li>
                <li class="uk-active">
	                <a href="javascript:scrollNotice();" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Noticias
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#modal" uk-toggle class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Contactenos
	                </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="uk-navbar-center">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a class="uk-animation-toggle">
            		<img src="{{ asset('img/logoHeader.png') }}" class="logoHeader uk-animation-shake uk-animation-reverse"/>
            	</a>
            </li>            
        </ul>
    </div>
</div>

<!-- This is the modal -->
<div id="modal" uk-modal class="row">
    <div class="uk-modal-dialog uk-modal-body col s12">
        <h2 class="uk-modal-title" align="center" style="padding-top:10px">Ingresa los siguientes datos y cuentanos que podemos hacer por ti.</h2>
        <hr class="uk-divider-icon">
        <div class="col s12">
			<p style="padding-right:10px;">Campos obligatorios (<span class="red-text"> * </span>)</p>
		</div>
        {!! Form::open(['route' => 'contacts.store', 'method' => 'POST']) !!}
	        
	        <div class="uk-margin col s12 m6 l6">
		        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Nombre Completo <span class="red-text">*</span></label>
		        <div class="uk-form-controls">
		        	{!! Form::text('nombre',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************']) !!}    
		        </div>
		    </div>

					
	        <div class="uk-margin col s12 m6 l6">
		        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Apellido Completo <span class="red-text">*</span></label>
		        <div class="uk-form-controls">
		            {!! Form::text('apellido',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************']) !!}
		        </div>
		    </div>
		    
		    <div class="uk-margin col s12 m6 l6">
		        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Email <span class="red-text">*</span></label>
		        <div class="uk-form-controls">
		            {!! Form::email('email',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2','required','placeholder' => 'example@gmail.com']) !!}
		        </div>
		    </div>
		    
		    <div class="uk-margin col s12 m6 l6">
		        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Telefono <span class="red-text">*</span></label>
		        <div class="uk-form-controls">
		            {!! Form::tel('telefono',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2']) !!}
		        </div>
		    </div>
		    
		    <div class="uk-margin col s12">
	            <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Mensaje <span class="red-text">*</span></label>
				 <div class="uk-form-controls">
					{!! Form::textarea('mensaje',null,['id' => 'form-stacked-text','class' => 'uk-textarea z-depth-2','required','placeholder' => '*******************']) !!}
				</div>			            
	        </div>
	        
	        <div class="col s12" align="center" style="padding-bottom:10px">
	        	{!! Form::submit('Enviar', ['class' => 'uk-button uk-button-default black white-text z-depth-4','style' => 'border:none']) !!}
	        </div>
        {!! Form::close() !!}
    </div>
</div>