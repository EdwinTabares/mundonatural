@extends('front.template.main')

@section('title', '�Quienes Somos? | Bienvenido')

@section('content')

	<div class="container-fluid">
		<div class="row">
			<div class="col s12" style="padding-top: 120px;padding-bottom:100px;">
				
				<div class="col s12 z-depth-2" style="padding-top: 20px">
					<div class="col s12 m6 l6">
						<h2 align="center" class="uk-animation-scale-up delay-1">Mision </h2>
						<hr class="uk-divider-icon">
						<p style="word-wrap: break-word;" align="center" class="uk-animation-scale-up delay-1">
							 Somos una empresa en brindar servicios de aseo integral, actuanco con calidad, 
							 oportunidad y experiencia. Orientados por la filosofia del mejoramiento continuo 
							 y el cuidado del medio ambiente. Soportados en un excelente talento humano 
							 que trabaja con esfuerzo, dedicacion, para satisfacer las necesidades de nuestros clientes.
						</p>
					</div>
					
					<div class="col s12 m6 l6">
						<h2 align="center" class="uk-animation-scale-up delay-1">Vision </h2>
						<hr class="uk-divider-icon">
						<p style="word-wrap: break-word;" align="center" class="uk-animation-scale-up delay-1">
							En el 2024 consolidarnos en el eje cafetero como una de las empresas mas competitivas del mercado.
						</p>
					</div>
				</div>
				
			</div>
		</div>
	</div>

@endsection