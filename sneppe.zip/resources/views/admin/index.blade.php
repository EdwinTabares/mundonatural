@extends('admin.template.main')

@section('title', 'Panel Administrativo Sneppe | Bienvenido')

@section('content')

	<div class="container-fluid">
		<div class="row">
			<div class="col s12">
				
				<div class="col s12" style="padding-top: 50px" align="center">
					<h1 class="uk-animation-scale-up delay-1">&#161;Bienvenido al Panel Administrativo de Sneppe!</h1>
					<hr class="uk-divider-icon">
					<img src="{{ asset('img/logo.png') }}" style="width: 300px; heigth: 350px" class="uk-animation-scale-up delay-3"/>
				</div>

			</div>
		</div>
	</div>

@endsection

@section('js')

@endsection