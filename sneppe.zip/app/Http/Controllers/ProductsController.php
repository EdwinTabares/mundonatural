<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Modelo\Product;
use App\Modelo\Image;
use Illuminate\Support\Facades\Storage;

class ProductsController extends Controller
{
  
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = Product::paginate(6);
        return view('admin.product.index')->with('product',$product);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.product.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // registra  el producto
         $product = new  Product($request->all());
         $product->save();
         $imagenes = $request->file('imagenes');
        foreach ($imagenes as $id => $imagen) 
        {
            $name = 'imgProductos'. $id . time().$imagen->getClientOriginalExtension();
            $imagen->storeAs('/public/productos',$name);
            $image = new Image();
            $image->nombre = $name;
            $image->product_id = $product->id;
            $image->save();
        }
        return redirect('panel/products');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = Product::find($id);
        return view('admin.product.edit')->with('product',$product);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::find($id);
        return view('admin.product.edit')->with('product',$product);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $product = Product::find($id);
         $product->fill($request->all());
         $product->save();
         return redirect('/panel/products');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::find($id);
       foreach ($product->imagenes as $imagen) {
           Storage::delete('/public/productos/'.$imagen->nombre);
       }
       
       $product->delete();
       return redirect('/panel/products');
    }
}
