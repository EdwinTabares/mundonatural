<?php

namespace App\Modelo;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    
	 /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'nombre', 'service_id','product_id'
    ];

     public function servicio()
    {
        return $this->belongsTo('App\Modelo\Service','service_id');
    }

    public function producto()
    {
        return $this->belongsTo('App\Modelo\Product','product_id');
    }
}
