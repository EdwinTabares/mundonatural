<?php

namespace App\Modelo;

use Illuminate\Database\Eloquent\Model;

class Contacto extends Model
{
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'nombre','apellido', 'email','telefono','mensaje'
    ];

}
