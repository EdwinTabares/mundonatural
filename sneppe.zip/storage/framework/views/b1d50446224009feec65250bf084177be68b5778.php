<?php $__env->startSection('title', 'Sneppe | Bienvenido'); ?>

<?php $__env->startSection('content'); ?>

	<div class="container-fluid">
		<div class="row">
			<div class="col s12" style="padding-top: 100px;padding-bottom:100px;">
				
				<div class="col s12 m6 l6" style="padding-top: 70px">
					<h2 align="center" class="uk-animation-scale-up delay-1">Grupo Empresarial Sneppe S.A.S </h2>
					<hr class="uk-divider-icon">
					<p style="word-wrap: break-word;" align="center" class="uk-animation-scale-up delay-1">
						Grupo Empresarial <b><span class="green-text">S</span><span class="blue-text">nep</span><span class="green-text">pe</span></b> SAS es una empresa
						prestadora de servicios integrales de aseo, determinada por la experiencia, asesoria, image
						y cumplimiento legal. Nuestros servicios se caracterizan por calidad de los materiales y equipos
						empleados. <b><span class="green-text">S</span><span class="blue-text">nep</span><span class="green-text">pe</span></b> SAS est&#225; comprometida con el sistema 
						de gestion integral buscando constantemente la mejora continua en todos los procesos.
					</p>
				</div>
				
				<div class="col s12 m6 l6" style="padding-top: 30px;" align="center">
					<img src="<?php echo e(asset('img/logo.png')); ?>" style="width: 300px; heigth: 350px" class="uk-animation-scale-up delay-3"/>
				</div>
				
			</div>
		</div>
	</div>
	
	<div class="container" >
		<div class="row z-depth-4-blue" style="padding-left:10px;padding-right:10px;">
			<div class="col s12">
				
				<div class="col s12" align="center" style="padding-bottom: 10px;padding-top:20px;">
					<h1 class="noticias">Noticias</h1>
				</div>
				
				<div class="row">
					<div class="col s12 z-depth-2">
						<div class="col s12 m6 l6" style="padding-top: 30px;padding-bottom: 10px;" align="center">
							<a href="<?php echo e(asset('img/notice.png')); ?>" data-fancybox>
								<img src="<?php echo e(asset('img/notice.png')); ?>" style="padding-top: 15px;padding-bottom: 15px;width: 80%; height: 300px;" class="uk-animation-scale-up delay-3"/>
							</a>
						</div>
						
						<div class="col s12 m6 l6" style="padding-top: 50px">
							<h2 align="center" class="uk-animation-scale-up delay-1">Noticia 1</h2>
							<hr class="uk-divider-icon">
							<p style="word-wrap: break-word;" align="center" class="uk-animation-scale-up delay-1">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos sint voluptatum sit, perspiciatis ipsa, velit possimus dignissimos magni cum illo ab, dolore consectetur asperiores repellat atque, ipsum magnam. Vel, officia.
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos sint voluptatum sit, perspiciatis ipsa, velit possimus dignissimos magni cum illo ab, dolore consectetur asperiores repellat atque, ipsum magnam. Vel, officia.
							</p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<!--SCRIPT PARA DESPLAZAR HASTA NOTICIAS-->
	<script>
		function scrollNotice(){
			$('html,body').animate({
		        scrollTop: $(".noticias").offset().top
		    }, 1000);
		}
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>