<?php $__env->startSection('title', 'Crear Noticia | Sneppe'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col s12" style="padding-top: 50px; padding-bottom: 50px;">
				
				<?php echo Form::model($notice); ?>

								
			        <div class="uk-margin col s12">
				        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Titulo</label>
				        <div class="uk-form-controls">
				        	<?php echo Form::text('titulo',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************','readonly']); ?>    
				        </div>
				    </div>
							
					<div class="uk-margin col s12">
			            <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Descripcion</label>
						 <div class="uk-form-controls">
							<?php echo Form::textarea('descripcion',null,['id' => 'form-stacked-text','class' => 'uk-textarea z-depth-2','required','placeholder' => '*******************','readonly']); ?>

						</div>			            
			        </div>

				<?php echo Form::close(); ?>

				
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>