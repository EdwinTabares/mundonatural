<?php $__env->startSection('title', 'Panel Administrativo Sneppe | Bienvenido'); ?>

<?php $__env->startSection('content'); ?>

	<div class="container-fluid">
		<div class="row">
			<div class="col s12">
				
				<div class="col s12" style="padding-top: 50px" align="center">
					<h1 class="uk-animation-scale-up delay-1">&#161;Bienvenido al Panel Administrativo de Sneppe!</h1>
					<hr class="uk-divider-icon">
					<img src="<?php echo e(asset('img/logo.png')); ?>" style="width: 300px; heigth: 350px" class="uk-animation-scale-up delay-3"/>
				</div>

			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>