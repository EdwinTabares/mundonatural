<?php $__env->startSection('title', 'Productos | Bienvenido'); ?>

<?php $__env->startSection('content'); ?>
	
	<nav class="uk-navbar-container transparent" uk-navbar>
	    <div class="uk-navbar-left">
	        <ul class="uk-navbar-nav">
	            <li class="uk-active uk-animation-toggle">
	            	<a class="uk-animation-shake uk-animation-reverse uk-button uk-button-default black white-text z-depth-4" href="<?php echo e(route('products.create')); ?>" 
	            	style="margin-top:40px;margin-bottom:40px;margin-left:40px;border:none;width:150px;height:50px;">
	            		Crear Producto
	            	</a>
	            </li>
	        </ul>
	    </div>
	
	    <div class="uk-navbar-right">
	        <form class="uk-search uk-search-default z-depth-4" style="margin-top:40px;margin-bottom:40px;margin-right:40px">
			    <span uk-search-icon></span>
			    <input class="uk-search-input" type="search" placeholder="Buscar servicios...">
			</form>
	    </div>
	</nav>
	
	<div class="uk-overflow-auto">
		<table class="uk-table uk-table-divider">
		    <thead>
		        <tr>
		            <th style="text-align: center">Nombre</th>
		            <th style="text-align: center">Acc&#237;on</th>
		        </tr>
		    </thead>
		    <tbody>
		        <tr>
		            <td style="text-align: center">Diego Villa</td>
		            <td style="text-align: center">
		            	<a class="uk-button uk-button-default blue black-text z-depth-4" href="" style="border:none">
	            			<i class="fa fa-eye fa-2x" aria-hidden="true"></i>
	            		</a>
	            		<a class="uk-button uk-button-default orange black-text z-depth-4" href="" style="border:none">
	            			<i class="fa fa-edit fa-2x" aria-hidden="true"></i>
	            		</a>
	            		<a class="uk-button uk-button-default red black-text z-depth-4" href="" style="border:none">
	            			<i class="fa fa-remove fa-2x" aria-hidden="true"></i>
	            		</a>
		            </td>
		        </tr>
		    </tbody>
		</table>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>