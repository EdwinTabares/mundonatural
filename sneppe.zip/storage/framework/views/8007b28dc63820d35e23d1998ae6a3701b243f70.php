<div class="row grey darken-4">

	<div class="col s12" style="padding-top: 30px; padding-bottom: 30px;">
		<div class="col s12 m6 l6" align="center">
			<img src="<?php echo e(asset('img/logoFooterMedrar.png')); ?>"/>
		</div>
			
		<div class="col s12 m6 l6" align="center" style="padding-top: 20px;">
			<a href="https://www.facebook.com/medrarsof" target="_blank">
				<img src="<?php echo e(asset('img/redes/facebook.png')); ?>" class="z-depth-4"/>
			</a>
			<a href="https://twitter.com/medrarsyc" target="_blank">
				<img src="<?php echo e(asset('img/redes/twitter.png')); ?>" class="z-depth-4"/>
			</a>
			<a href="https://www.instagram.com/medrarsof/" target="_blank">
				<img src="<?php echo e(asset('img/redes/instagram.png')); ?>" class="z-depth-4"/>
			</a>
		</div>
	</div>
	
	<div class="col s12 black" style="padding-top: 10px;">
		<div class="col s12" align="center" style="padding-top: 30px;">
			<p class="white-text">&#169; 2017 MedrarSof. All Rights Reserved</p>
		</div>
	</div>
	
</div>