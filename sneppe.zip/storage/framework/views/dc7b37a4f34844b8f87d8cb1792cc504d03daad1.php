<nav class="uk-navbar-container z-depth-4 black" uk-navbar id="navMax">

    <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="<?php echo e(route('front.index')); ?>" class="uk-animation-toggle">
            		<img src="<?php echo e(asset('img/logoHeader.png')); ?>" class="logoHeader uk-animation-shake uk-animation-reverse"/>
            	</a>
            </li>            
        </ul>
    </div>

    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="<?php echo e(route('front.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		Inicio
            	</a>
            </li>
            <li class="uk-active">
            	<a href="<?php echo e(route('front.about')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		&#191;Qui&#233;nes Somos?
            	</a>
            </li>
            <li class="uk-active">
	            <a href="#" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Productos
	            </a>
            </li>
            <li class="uk-active">
	            <a href="#" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Servicios
	            </a>
            </li>
            <li class="uk-active">
	            <a href="javascript:scrollNotice();" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Noticias
	            </a>
            </li>
            <li class="uk-active">
	            <a href="#modal" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Contactenos
	            </a>
            </li>
        </ul>
    </div>
    
</nav>

<div class="uk-navbar-container black z-depth-4" uk-navbar id="navMin">
    <div class="uk-navbar-left">
	    <button class="uk-button uk-button-default" id="button1" type="button" 
	    	style="margin:20px; border:none; width: 70px; height: 50px" 
	    		onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);border:none;width: 70px; height: 50px;margin:20px;'" 
	          	onMouseOut="this.style.cssText='background-color: transparent;border:none;width: 70px; height: 50px;margin:20px;'">
	    	<i id="icon" class="fa fa-plus white-text" align="center" style="font-size:18px" aria-hidden="true" 
	    		onMouseOver="this.style.cssText='font-size: 20px;'" 
	            onMouseOut="this.style.cssText='font-size: 18px;'"></i>
	    </button>
        <div uk-dropdown="mode: click;" class="black z-depth-4-white">
            <ul class="uk-nav uk-dropdown-nav black">
                <li class="uk-active">
	               	<a href="<?php echo e(route('front.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	               		Inicio
	               	</a>
                </li>
                <li class="uk-active">
	                <a href="#" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	&#191;Qui&#233;nes Somos?
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Productos
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Servicios
	                </a>
                </li>
                <li class="uk-active">
	                <a href="javascript:scrollNotice();" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Noticias
	                </a>
                </li>
                <li class="uk-active">
	                <a href="#modal" uk-toggle class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Contactenos
	                </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="uk-navbar-center" style="padding-top: 20px;">
        <p class="white-text">Sneppe S.A.S</p>
    </div>
</div>

<!-- This is the modal -->
<div id="modal" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <h2 class="uk-modal-title">Headline</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <p class="uk-text-right">
            <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
            <button class="uk-button uk-button-primary" type="button">Save</button>
        </p>
    </div>
</div>