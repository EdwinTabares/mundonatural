<nav class="uk-navbar-container z-depth-4 black" uk-navbar id="navMax">

    <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="<?php echo e(route('panel.index')); ?>" class="uk-animation-toggle">
            		<img src="<?php echo e(asset('img/logoMedrar.png')); ?>" class="logoHeader uk-animation-shake uk-animation-reverse"/>
            	</a>
            </li>            
        </ul>
    </div>

    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
            	<a href="<?php echo e(route('panel.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		Inicio
            	</a>
            </li>
            <li class="uk-active">
            	<a href="<?php echo e(route('users.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
            		Usuarios
            	</a>
            </li>
            <li class="uk-active">
	            <a href="<?php echo e(route('products.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Productos
	            </a>
            </li>
            <li class="uk-active">
	            <a href="<?php echo e(route('services.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Servicios
	            </a>
            </li>
            <li class="uk-active">
	            <a href="<?php echo e(route('notices.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Noticias
	            </a>
            </li>
            <li class="uk-active">
	            <a href="<?php echo e(route('contacts.index')); ?>" class="white-text" onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='background-color: transparent;font-size: 14px;'">
	            	Contactos
	            </a>
            </li>
        </ul>
    </div>
    
</nav>

<div class="uk-navbar-container black z-depth-4" uk-navbar id="navMin">
    <div class="uk-navbar-left">
	    <button class="uk-button uk-button-default" id="button1" type="button" 
	    	style="margin:20px; border:none; width: 70px; height: 50px" 
	    		onMouseOver="this.style.cssText='background-color: rgba(255, 255, 255, 0.2);border:none;width: 70px; height: 50px;margin:20px;'" 
	          	onMouseOut="this.style.cssText='background-color: transparent;border:none;width: 70px; height: 50px;margin:20px;'">
	    	<i id="icon" class="fa fa-plus white-text" align="center" style="font-size:18px" aria-hidden="true" 
	    		onMouseOver="this.style.cssText='font-size: 20px;'" 
	            onMouseOut="this.style.cssText='font-size: 18px;'"></i>
	    </button>
        <div uk-dropdown="mode: click;" class="black z-depth-4-b">
            <ul class="uk-nav uk-dropdown-nav black">
                <li class="uk-active">
	               	<a href="<?php echo e(route('panel.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	               		Inicio
	               	</a>
                </li>
                <li class="uk-active">
	                <a href="<?php echo e(route('users.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Usuarios
	                </a>
                </li>
                <li class="uk-active">
	                <a href="<?php echo e(route('products.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Productos
	                </a>
                </li>
                <li class="uk-active">
	                <a href="<?php echo e(route('services.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Servicios
	                </a>
                </li>
                <li class="uk-active">
	                <a href="<?php echo e(route('notices.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Noticias
	                </a>
                </li>
                <li class="uk-active">
	                <a href="<?php echo e(route('contacts.index')); ?>" class="white-text" onMouseOver="this.style.cssText='font-size: 16px;'" 
	            	onMouseOut="this.style.cssText='font-size: 14px;'">
	                	Contactos
	                </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="uk-navbar-center" style="padding-top: 20px;">
        <p class="white-text">Panel Sneppe S.A.S</p>
    </div>
</div>