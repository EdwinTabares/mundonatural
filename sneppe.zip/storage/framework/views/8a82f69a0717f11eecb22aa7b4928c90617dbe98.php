<!DOCTYPE html>
<html class="black">
	<head>
		<title><?php echo $__env->yieldContent('title', 'Default'); ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<link rel="stylesheet" href="<?php echo e(asset('plugins/uikit/css/uikit.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('css/estilosAdmin.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('css/colores.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('css/grid.css')); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">
	</head>

	<body class="white">
		
		<header>
			<?php echo $__env->make('admin.template.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</header>

		<!--LLAMAMOS EL CONTENIDO-->
		<?php echo $__env->yieldContent('content'); ?>
		<a href="javascript:" id="return-to-top" class="z-depth-4"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>

		<footer>
			<?php echo $__env->make('admin.template.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</footer>
		
		<!--JQUERY PARA LOS EVENTOS-->
		<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/uikit/js/uikit.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/uikit/js/uikit-icons.js')); ?>"></script>
		
		<script>
			$("#button1").click(function(){
			    if ($('#icon').hasClass('fa-plus')){
			        $('#icon').addClass('fa-remove');
			        $('#icon').removeClass('fa-plus');
			    }else {
			        $('#icon').removeClass('fa-remove');
			        $('#icon').addClass('fa-plus');
			    }
			});
		</script>
		
		<script>
			// ===== Scroll to Top ==== 
			$(window).scroll(function() {
			    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
			        $('#return-to-top').fadeIn(200);    // Fade in the arrow
			    } else {
			        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
			    }
			});
			$('#return-to-top').click(function() {      // When arrow is clicked
			    $('body,html').animate({
			        scrollTop : 0                       // Scroll to top of body
			    }, 500);
			});
		</script>
		
		<!--LLAMAMOS LOS SCRIPTS DE CADA PAGINA-->
		<?php echo $__env->yieldContent('js'); ?>
		
	</body>
</html>