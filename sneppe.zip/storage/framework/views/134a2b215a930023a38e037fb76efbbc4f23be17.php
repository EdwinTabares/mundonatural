<?php $__env->startSection('title', 'Crear Producto | Sneppe'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col s12" style="padding-top: 50px; padding-bottom: 50px;">
				
				<div class="col s12">
					<p style="padding-right:10px;">Campos obligatorios (<span class="red-text"> * </span>)</p>
				</div>
				
				<?php echo Form::open(['route' => 'products.store', 'method' => 'POST','files' => true ]); ?>

								
			        <div class="uk-margin col s12">
				        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Nombre Completo <span class="red-text">*</span></label>
				        <div class="uk-form-controls">
				        	<?php echo Form::text('titulo',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','placeholder' => '*******************']); ?>    
				        </div>
				    </div>
							
					<div class="uk-margin col s12">
			            <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Mensaje <span class="red-text">*</span></label>
						 <div class="uk-form-controls">
							<?php echo Form::textarea('descripcion',null,['id' => 'form-stacked-text','class' => 'uk-textarea z-depth-2','placeholder' => '*******************']); ?>

						</div>			            
			        </div>
			        
			        <div class="col s12" align="center">
				        <label class="uk-form-label" for="form-stacked-text" style="font-size:15px;">Imagen(es) <span class="red-text">*</span></label>
				        <div class="uk-form-controls">
				        <?php echo Form::file('imagenes[]', ['id' => 'form-stacked-text', 'class' => 'file-loading archivos', 'multiple' => true]); ?>

				        </div>
				    </div>

				    <div class="uk-animation-toggle uk-margin col s12" align="center">
						<?php echo Form::submit('Crear Producto', ['class' => 'uk-animation-shake uk-animation-reverse uk-button uk-button-default black white-text z-depth-4','style' => 'border:none']); ?>

				    </div>
				
				<?php echo Form::close(); ?>

				
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script>
		$('.archivos').fileinput({
			uploadAsync: false,
			showUpload: false,
			showRemove: false,
			minFileCount: 1,
			maxFileCount: 10,
			browseClass: "uk-button uk-button-default red white-text z-depth-4",
        	browseLabel: "Subir Imagen(es)",
        	browseIcon: "<i class=\"fa fa-picture-o\"></i> "
		});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>