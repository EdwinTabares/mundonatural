<?php $__env->startSection('title', 'Usuario | Sneppe'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col s12" style="padding-top: 50px; padding-bottom: 50px;">
					
				<?php echo Form::model($user,[]); ?>	
											
			        <div class="uk-margin col s12 m6 l6">
				        <?php echo Form::label('nombre', 'Nombre Completo', ['for' => 'form-stacked-text','class' => 'uk-form-label']); ?>

				        <div class="uk-form-controls">
				        	<?php echo Form::text('nombre',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************','readonly']); ?>    
				        </div>
				    </div>
							
			        <div class="uk-margin col s12 m6 l6">
				        <?php echo Form::label('apellido', 'Apellido Completo', ['for' => 'form-stacked-text','class' => 'uk-form-label']); ?>

				        <div class="uk-form-controls">
				            <?php echo Form::text('apellido',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************','readonly']); ?>

				        </div>
				    </div>
				    
				    <div class="uk-margin col s12 m6 l6">
				        <?php echo Form::label('email', 'Email', ['for' => 'form-stacked-text','class' => 'uk-form-label']); ?>

				        <div class="uk-form-controls">
				            <?php echo Form::email('email',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => 'example@gmail.com','readonly']); ?>

				        </div>
				    </div>
				    
				    <div class="uk-margin col s12 m6 l6">
				        <?php echo Form::label('password', 'Password', ['for' => 'form-stacked-text','class' => 'uk-form-label']); ?>

				        <div class="uk-form-controls">
				            <?php echo Form::text('email',null,['id' => 'form-stacked-text','class' => 'uk-input z-depth-2', 'type' => 'text','required','placeholder' => '*******************','readonly']); ?>

				        </div>
				    </div>
				    
				<?php echo Form::close(); ?>

							
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>